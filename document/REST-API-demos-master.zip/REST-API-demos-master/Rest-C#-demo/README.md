# Huobi.Rest.CSharp.Demo
 

### Useage:
```csharp
    HuobiApi api = new HuobiApi("accessKey","seceretKey");
    var result = api.GetAllAccount();
```

