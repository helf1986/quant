# README
## 环境要求
nodejs 6.0以上版本

## Demo说明
1. demo_crawler.js
同时用rest和ws取行情数据，并返回其中的差异

2. demo_sdk.js
演示交易接口的调试流程 

## 使用指南
```
npm install
node demo_sdk.js 
node demo_crawler.js
```

## 联系作者
magicdlf (QQ:2797820732)
最新demo代码:
https://github.com/magicdlf/huobipro
