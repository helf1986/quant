#huobi-qt-rest

GitHub: https://github.com/qyvlik

# http api binding



头文件：[huobiapi.h](./src/qtqutotrade/market/huobi/huobiapi.h)

源文件 [huobiapi.cpp](./src/qtqutotrade/market/huobi/huobiapi.cpp)

http 请求工具类：[httputils](./src/qtqutotrade/utils/httputils.h)



# huobi api test

测试代码在 [tst_testhuobiapi.cpp](./tests/auto/tst_huobi_api/tst_testhuobiapi.cpp)



## run



去 [qt download](download.qt.io) 下载对应桌面系统的 qt，然后一键安装，然后打开 qtcreator ，一键打开 