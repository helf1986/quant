﻿package config

// API KEY
const (
	ACCESS_KEY string = ""
	SECRET_KEY string = ""
)

// API请求地址, 不要带最后的/
const (
	MARKET_URL string = "https://api.huobi.pro"
	TRADE_URL  string = "https://api.huobi.pro"
)
