package main

import (
	"fmt"
)

func main() {
	fmt.Println("火币")
}
