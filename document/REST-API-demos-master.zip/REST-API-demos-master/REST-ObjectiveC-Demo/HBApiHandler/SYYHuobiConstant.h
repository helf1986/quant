//
//  SYYHuobiConstant.h
//
//  Created by 似云悠 on 2017/12/7.
//  Copyright © 2017年 syy. All rights reserved.
//

#ifndef SYYHuobiConstant_h
#define SYYHuobiConstant_h

#define kBaseUrl @"https://api.huobi.pro"
#define kHBAccessKey @"xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxx"
#define kHBSecretKey @"xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxx"
#endif /* SYYHuobiConstant_h */
