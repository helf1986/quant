# RESTAPI-demos

demos for REST API.

使用demo前请仔细阅读[API文档](https://github.com/huobiapi/API_Docs/wiki)

常见问题请参考[FAQ](https://github.com/huobiapi/API-FAQ/wiki)

所有demo均来自热心用户，欢迎大家提交各种语言的demo。可加入api交流QQ群 597821383（加群需要同时提供uid和编程语言）进行问题咨询
