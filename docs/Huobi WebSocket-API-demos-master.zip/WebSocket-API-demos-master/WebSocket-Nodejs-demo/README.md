# README
## 环境要求
nodejs 6.0以上版本

## Demo说明
ws.js
演示使用websocket获取深度和K线数据

## 使用指南
```
npm install
node ws.js
```

## 联系作者
magicdlf (QQ:2797820732)
最新demo代码:
https://github.com/magicdlf/huobipro
