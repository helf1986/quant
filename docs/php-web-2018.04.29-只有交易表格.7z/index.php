<?php
/**
 *
 * @author 李操
 * @date   2018-04-27 20:15:40
 */

define('BASE_DIR', __DIR__ . '/');

require_once BASE_DIR . 'bqAdmin/core/config.php';
require_once ADMIN_DIR . 'core/mongodbClient.php';
require_once ADMIN_DIR . 'core/functions.php';

//页面：
$act = empty($_GET['act']) || trim($_GET['act']) == '' ? '' : trim($_GET['act']);


$mongo = new mongodbClient($baseConfig['mongodb']);

session_start();
if ($act != 'login' && empty($_SESSION['userName'])) {
	header('Location: /login.php');
	exit;
}

switch ($act) {
	case 'tradeList':
		require_once ADMIN_DIR . 'trade_list.php';
		break;
	case 'performance':
		//$url = '/bqAdmin/performance.php';
		//require_once ADMIN_DIR . 'main.php';
		require_once ADMIN_DIR . 'performance.php';
		break;
	case 'login':
		checkLogin();
		break;
	default:
		header('Location: /login.php');
		break;
}
exit;