<?php
/**
 *
 * @author 李操
 * @date   2018-04-28 10:30:40
 */


?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8"/>
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>登录</title>
    <link href="/bqAdmin/assets/css/bootstrap.min.css" rel="stylesheet"/>

    <!--[if lt IE 9]>
    <script src="/bqAdmin/assets/js/html5shiv.js"></script>
    <script src="/bqAdmin/assets/js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div style="background:white;height:100%;" class="container-fluid">
    <div style="height:100%;" class="row">
        <div style="height:100%;background:white;margin:0px;overflow-y:auto;padding:0px;" class="col-md-12" id="mainwindow">
            <div id="main_page" style="padding:16px;">
                <div style="width:400px;border:1px solid #ddd; margin-left: auto;margin-right: auto;">
                    <div style="background:#f5f5f5;padding:20px;position:relative;text-align:center;">
                        <h4 style="text-align: center;">用户登录</h4>
                        <div>
                            <form method="post" action="/?act=login&type=do">
                                <div class="form-group">
                                    <input type="text" required="required" placeholder="登录名" name="userName" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="password" required="required" placeholder="密码" name="password" class="form-control">
                                </div>
                                <button class="btn btn-success" style="text-align:center;">登录</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>