<?php
/**
 * 交易记录列表
 * @author 李操
 * @date   2018-04-27 20:17:00
 */
if (!defined('BASE_DIR')) exit('No direct script access allowed');

include_once "header.php";

$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$pageSize = 50; //每页显示50条记录
$offset = ($page - 1) * $pageSize;
$baseUrl = '/info/trade_list.php';

$wheres = array(); // 搜索条件
$sort = array('ordtime' => 1); //排序

$tradeCount = getTradeCount($wheres);
$pageCount = ceil($tradeCount / $pageSize); //总页数
$tradeList = listTrade($wheres, $sort, $offset, $pageSize);

?>
    <div class="main-content">
        <div class="breadcrumbs" id="breadcrumbs">
            <script type="text/javascript">
                try {
                    ace.settings.check('breadcrumbs', 'fixed')
                } catch (e) {
                }
            </script>

            <ul class="breadcrumb">
                <li>
                    <i class="icon-home home-icon"></i>
                    <a href="#">Home</a>
                </li>
                <li>
                    <a href="#">交易记录</a>
                </li>
            </ul><!-- .breadcrumb -->

            <div class="nav-search" id="nav-search">
                <form class="form-search">
                            <span class="input-icon">
                                <input type="text" placeholder="Search ..." class="nav-search-input"
                                       id="nav-search-input" autocomplete="off"/>
                                <i class="icon-search nav-search-icon"></i>
                            </span>
                </form>
            </div><!-- #nav-search -->
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->
                    <div class="row">
                        <div class="col-xs-12">
                            <!--
                            <div class="table-header">
                                搜索条件位置
                            </div>
                            -->
                            <div class="table-responsive">
                                <table id="sample-table-2" class="table table-striped table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th class="center">用户ID</th>
                                        <th class="center">策略ID</th>
                                        <th class="center">计价币种</th>
                                        <th class="center">交易所</th>
                                        <th class="center">交易所用户ID</th>
                                        <th class="center">交易所订单ID</th>
                                        <th class="center">下单时间</th>
                                        <th class="center">下单时间戳</th>
                                        <th class="center">数币代码</th>
                                        <th class="center">交易方向</th>
                                        <th class="center">交易数量</th>
                                        <th class="center">下单价格</th>
                                        <th class="center">下单金额</th>
                                        <th class="center">成交时间戳</th>
                                        <th class="center">成交数量</th>
                                        <th class="center">成交价格</th>
                                        <th class="center">成交金额</th>
                                        <th class="center">手续费</th>
                                        <th class="center">订单状态</th>
                                    </tr>
                                    </thead>

                                    <tbody>
									<?php
									foreach ($tradeList as $row) {
										?>
                                        <tr>
                                            <td><?php echo $row->usr ?></td>
                                            <td><?php echo $row->sch ?></td>
                                            <td><?php echo $row->cur ?></td>
                                            <td><?php echo $row->exg ?></td>
                                            <td><?php echo $row->usrex ?></td>
                                            <td><?php echo $row->ordid ?></td>
                                            <td><?php echo formatTime($row->ordtime) ?></td>
                                            <td><?php echo formatTime($row->ordutc) ?></td>
                                            <td><?php echo $row->sym ?></td>
                                            <td><?php echo showDirection($row->dir) ?></td>
                                            <td><?php echo $row->vol ?></td>
                                            <td><?php echo $row->price ?></td>
                                            <td><?php echo $row->amt ?></td>
                                            <td><?php echo formatTime($row->tfill) ?></td>
                                            <td><?php echo $row->volfill ?></td>
                                            <td><?php echo $row->pricefill ?></td>
                                            <td><?php echo $row->amtfill ?></td>
                                            <td><?php echo $row->fee ?></td>
                                            <td><?php echo $row->status ?></td>
                                        </tr>
										<?php
									}
									?>
                                    </tbody>
                                </table>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="dataTables_info" id="sample-table-2_info">页码： <?php echo $page ?> / <?php echo $pageCount ?>，共 <?php echo $tradeCount ?>条记录
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="dataTables_paginate paging_bootstrap">
                                            <ul class="pagination">
                                                <li class="prev"><a href="<?php echo $baseUrl ?>">首页</a></li>
                                                <li class="prev">
                                                    <a href="<?php echo getPrePageUrl($baseUrl, $page) ?>">上一页</a>
                                                </li>
                                                <li class="next">
                                                    <a href="<?php echo getNextPageUrl($baseUrl, $page, $pageCount) ?>">下一页</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.page-content -->
    </div><!-- /.main-content -->
<?php
include_once "footer.php";
?>