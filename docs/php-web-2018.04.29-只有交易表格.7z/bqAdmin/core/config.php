<?php
/**
 *
 * @author 李操
 * @date   2018-04-28 10:00:00
 */
if (!defined('BASE_DIR')) exit('No direct script access allowed');

global $baseConfig, $mongo;
$baseConfig = parse_ini_file('config.ini');

define('ADMIN_DIR', BASE_DIR . 'bqAdmin/');



