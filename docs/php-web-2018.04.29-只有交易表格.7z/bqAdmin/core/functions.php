<?php
/**
 *
 * @author 李操
 * @date   2018-04-27 23:11:28
 */
if (!defined('BASE_DIR')) exit('No direct script access allowed');


/**
 * 获取交易数据列表
 * @param $wheres   搜索条件
 * @param $sort     排序
 * @param $offset   要忽略前面的记录数量
 * @param $limit    要获取的记录数量
 * @return mixed
 * @author 李操
 * @date   2018-04-27 23:47:46
 */
function listTrade($wheres, $sort, $offset, $limit) {
	global $mongo;
	$fields = 'usr, sch, cur, exg, usrex, ordid, ordtime, ordutc, sym, dir, vol, price, amt, tfill, volfill, pricefill, amtfill, fee, status';
	$mongo->setCollection('test_trade_list');
	return $mongo->findALL($wheres, $fields, $sort, $offset, $limit);
}

/**
 * 获取交易数据的总数
 * @param $wheres
 * @return mixed
 * @author 李操
 * @date   2018-04-28 23:55:10
 */
function getTradeCount($wheres) {
	global $mongo;
	$mongo->setCollection('test_trade_list');
	$mongo->setWheres($wheres);
	return $mongo->count();
}

/**
 * 显示交易方向
 * @param $direction
 * @return string
 * @author 李操
 * @date   2018-04-28 00:32:01
 */
function showDirection($direction) {
	switch ($direction) {
		case 1:
			return '多仓';
		case 0:
			return '平仓';
		case -1:
			return '空仓';
		default:
			return $direction;
	}
}

/**
 * 格式化时间戳
 * @param $timestamp
 * @return false|string
 * @author 李操
 * @date   2018-04-28 00:36:55
 */
function formatTime($timestamp) {
	return date('Y-m-d H:i:s', $timestamp);
}

/**
 * 获取上一页地址
 * @param  $url
 * @param  $page
 * @return string
 * @author 李操
 * @date   2018-04-28 00:51:03
 */
function getPrePageUrl($url, $page) {
	if ($page == 1) return '#';
	return $url . '?page=' . ($page - 1);
}

/**
 * 获取下一页地址
 * @param  $url
 * @param  $page
 * @param  $pageCount
 * @return string
 * @author 李操
 * @date   2018-04-28 00:50:49
 */
function getNextPageUrl($url, $page, $pageCount) {
	if ($pageCount > $page) return $url . '?page=' . ($page + 1);
	return '#';
}

/**
 * 临时登录方式
 * @author 李操
 * @date   2018-04-28 20:50:11
 */
function checkLogin() {
	$type = empty($_GET['type']) || trim($_GET['type']) == '' ? '' : trim($_GET['type']);
	switch ($type) {
		case 'do':
			global $baseConfig;
			$userName = empty($_POST['userName']) || trim($_POST['userName']) != $baseConfig['login']['userName'] ? '' : trim($_POST['userName']);
			$password = empty($_POST['password']) || trim($_POST['password']) != $baseConfig['login']['password'] ? '' : $_POST['password'];
			//echo '$userName:' . $userName . '    iN:' . $baseConfig['login']['userName'];
			//echo '$password:' . $password;
			//exit;
			if ($userName == '' || $password == '') header('Location: /login.php');
			
			
			session_start();
			$_SESSION['userName'] = $userName;
			header('Location: /?act=tradeList');
			exit;
		
		default :
			require_once BASE_DIR . 'login.php';
			break;
	}
}