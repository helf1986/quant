<?php
/**
 *
 * @author 李操
 * @date   2018-04-27 22:26:30
 */
if (!defined('BASE_DIR')) exit('No direct script access allowed');
include_once "header.php";

?>
    <div class="main-content" style="height:90%;">
        <div id="echartsContainer" style="height:40%; width:90%; margin-top:20px;"></div>
        <div id="test"></div>
        <script type="text/javascript" src="/bqAdmin/assets/js/echarts/echarts-v4.0.4.min.js"></script>
        <script type="text/javascript">
            var dom = document.getElementById("echartsContainer");
            var myChart = echarts.init(dom);

            //初始化数据（模拟）：
            var base = +new Date(1968, 9, 3);
            var oneDay = 24 * 3600 * 1000;
            var date = [];

            var data = [Math.random() * 300];

            for (var i = 1; i < 20000; i++) {
                var now = new Date(base += oneDay);
                date.push([now.getFullYear(), now.getMonth() + 1, now.getDate()].join('/'));
                data.push(Math.round((Math.random() - 0.5) * 20 + data[i - 1]));
            }
            setOption(myChart, date, data);

            //监听拖动事件：
            myChart.on("datazoom", dataZoomEvent);


            //拖动事件，动态加载数据
            function dataZoomEvent(param) {
                var minStart = 10;
                //var minEnd = 90;

                var start = -1;
                var end = -1;

                if (typeof param.batch === 'undefined') {
                    start = param.start;
                    end = param.end;

                    console.log("底部拖动, start：" + param.start);
                    //console.log(param);
                } else {
                    var data = param.batch[0];
                    start = data.start;
                    end = data.end;
                    console.log(data.start);
                    //console.log(data);
                }


                console.log(myChart.getModel().option.xAxis[0]);
                var axis = myChart.getModel().option.xAxis[0];
                var starttime = axis.data[axis.rangeStart];
                var endtime = axis.data[axis.rangeEnd];
                console.log("starttime:" + starttime, "   endtime:" + endtime + "   dataLength:" + axis.data.length);

                if (start == -1 || end == -1) return;


                //if (start < minStart) {
                //获取新数据：

                //}


            }

            // 异步加载数据
            function getData(myChart, dataType, page) {
                switch (dataType) {
                    case 'navData':
                        //净值数据：
                        $.get('/?act=ajax&type=navData&page=' + page).done(function (data) {
                            if (data == null || data == 'error') return;

                            //解释json，获取date & data:

                            //setOption(myChart, date, data);
                            return;
                        });
                        break;
                }
            }


            //画图模块
            function setOption(myChart, date, data) {
                //var dom = document.getElementById("echartsContainer");
                //var myChart = echarts.init(dom);
                //var app = {};

                /*
							option = null;
							var base = +new Date(1968, 9, 3);
							var oneDay = 24 * 3600 * 1000;
							var date = [];
				
							var data = [Math.random() * 300];
				
							for (var i = 1; i < 20000; i++) {
								var now = new Date(base += oneDay);
								date.push([now.getFullYear(), now.getMonth() + 1, now.getDate()].join('/'));
								data.push(Math.round((Math.random() - 0.5) * 20 + data[i - 1]));
							}
				*/

                var option = {
                    tooltip: {
                        trigger: 'axis',
                        position: function (pt) {
                            return [pt[0], '10%'];
                        }
                    },
                    title: {
                        left: 'center',
                        text: '净值',
                    },
                    toolbox: {
                        feature: {
                            dataZoom: {
                                yAxisIndex: 'none'
                            },
                            restore: {},
                            saveAsImage: {}
                        }
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: date
                        //axisLabel: {
                        //    interval: function (index, value) {
                        //        console.log("index:" + index + "   value:" + value);
                        //    }
                        //}
                    },
                    yAxis: {
                        type: 'value',
                        boundaryGap: [0, '100%']
                    },
                    dataZoom: [{
                        type: 'inside',
                        start: 90,
                        end: 100
                        //realtime: true,
                        //startValue: data.length - 900,
                        //endValue: data.length
                    }, {
                        start: 0,
                        end: 10,
                        handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                        handleSize: '80%',
                        handleStyle: {
                            color: '#fff',
                            shadowBlur: 3,
                            shadowColor: 'rgba(0, 0, 0, 0.6)',
                            shadowOffsetX: 2,
                            shadowOffsetY: 2
                        }
                    }],
                    series: [
                        {
                            name: '净值',
                            type: 'line',
                            smooth: true,
                            symbol: 'none',
                            sampling: 'average',
                            itemStyle: {
                                normal: {
                                    color: 'rgb(255, 70, 131)'
                                }
                            },
                            areaStyle: {
                                normal: {
                                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                        offset: 0,
                                        color: 'rgb(255, 158, 68)'
                                    }, {
                                        offset: 1,
                                        color: 'rgb(255, 70, 131)'
                                    }])
                                }
                            },
                            data: data
                        }
                    ]
                };
                ;
                if (option && typeof option === "object") {
                    myChart.setOption(option, true);
                }
            }

        </script>
    </div>
<?php
include_once "footer.php";
?>