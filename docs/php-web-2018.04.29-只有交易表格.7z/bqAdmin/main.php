<?php
/**
 *
 * @author 李操
 * @date   2018-04-28 22:35:04
 */

include_once "header.php";
?>
<iframe id="main" name="main" src="<?php echo $url ?>" scrolling=no width="100%" height="100%" frameborder="no"></iframe>
<?php
include_once "footer.php";
?>
